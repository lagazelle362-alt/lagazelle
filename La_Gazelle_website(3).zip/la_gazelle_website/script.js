const bigBags = document.getElementById("bigBags");
const weight = document.getElementById("weight");
const smallBags = document.getElementById("smallBags");
const total = document.getElementById("total");

function updateCalc() {
  let bags = Math.max(200, parseInt(bigBags.value || 200, 10));
  bigBags.value = bags;
  const kg = bags * 5;
  const small = bags * 50;
  const price = bags * 200;
  weight.textContent = kg.toLocaleString() + " kg";
  smallBags.textContent = small.toLocaleString();
  total.textContent = price.toLocaleString() + " MRU";
}
bigBags.addEventListener("input", updateCalc);
updateCalc();

document.getElementById("menuBtn").addEventListener("click", () => {
  document.getElementById("nav").classList.toggle("open");
});

document.querySelectorAll("#nav a").forEach(a => {
  a.addEventListener("click", () => document.getElementById("nav").classList.remove("open"));
});

document.getElementById("orderForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const data = new FormData(e.target);
  const bags = Number(data.get("bags"));
  const kg = bags * 5;
  const small = bags * 50;
  const totalMru = bags * 200;
  const subject = encodeURIComponent("La Gazelle wholesale order request");
  const body = encodeURIComponent(
`La Gazelle wholesale order request

Name: ${data.get("name")}
Company: ${data.get("company")}
Destination: ${data.get("country")}
Big bags: ${bags}
Total weight: ${kg} kg
Small bags: ${small}
Product total: ${totalMru} MRU
Payment method: ${data.get("payment")}

Please provide the shipping quotation and order confirmation.`
  );
  // Replace this email with the real La Gazelle sales email.
  window.location.href = `mailto:SALES_EMAIL_HERE@example.com?subject=${subject}&body=${body}`;
});
