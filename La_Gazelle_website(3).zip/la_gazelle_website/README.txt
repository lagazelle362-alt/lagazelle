LA GAZELLE WEBSITE — SETUP

1. Open index.html in a browser to preview the website.
2. Upload the entire folder to your web host.
3. Replace SALES_EMAIL_HERE@example.com in script.js with the real sales email.
4. Replace the visual placeholder packaging artwork with real La Gazelle product photos when available.
5. Before accepting live Visa/Mastercard payments, connect a PCI-compliant payment gateway. Do not store card numbers in this website.
6. Add real Bankily, Sedad, Masrivy and BIMBank account/payment instructions after you decide what information customers should see.
7. Shipping is intentionally a quote because the cost depends on destination, shipment size and freight arrangement.

CURRENT COMMERCIAL DATA
- Small bag: 100 g
- Big bag: 50 small bags = 5 kg
- Big bag price: 200 MRU
- Unit-equivalent price: 4 MRU / 100 g
- Product price: 40 MRU / kg
- Minimum wholesale: 1,000 kg = 200 big bags = 10,000 small bags
- Minimum product total: 40,000 MRU
- Delivery: Africa-wide, shipping quoted separately
- Payment methods shown: Bankily, Sedad, Masrivy, BIMBank, Visa, Mastercard
- Facebook: https://www.facebook.com/share/1BuTnJMy6E/?mibextid=wwXIfr
